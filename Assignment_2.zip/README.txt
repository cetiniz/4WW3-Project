Name: Zachary Cetinic
Student Number: 001419103
Enrolled in: CS 4WW3
Doing add-on task #1

Copyright info: Faces taken from my Facebook and friends Facebook with their permission; 
space background taken from pexels which is free to use under copyright; logo taken from 
noun project and credit is shown within actual logo; sample map is taken from google maps
Form validation for JavaScript was activated upon the onsubmit event. However, I also included a dynamic removal of red borders through the onfocus event. 
The GeoLocation for the search page works but is not linked to anything yet (not until we get into the dynamic part). 
The sites URL should be: https://cetiniz.cs4ww3.ca/
If you cannot access the site due to routing (or some permissions that were not enabled) email me at cetiniz@mcmaster.ca. I am fairly certain the site should be accessable outside of my IP
