Name: Zachary Cetinic
Student Number: 001419103
Enrolled in: CS 4WW3
Doing add-on task #1

Copyright info: Faces taken from my Facebook and friends Facebook with their permission; 
space background taken from pexels which is free to use under copyright; logo taken from 
noun project and credit is shown within actual logo; sample map is taken from google maps